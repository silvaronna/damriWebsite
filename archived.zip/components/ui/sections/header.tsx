import { Carousel } from "../carousel"

export function Header() {
  return (
    <div>
      <Carousel />
    </div>
  )
}
