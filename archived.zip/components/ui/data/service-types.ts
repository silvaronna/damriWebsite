export const serviceTypes = [
  { value: "antar-kota", label: "Bus Antar Kota" },
  { value: "dalam-kota", label: "Bus Dalam Kota" },
  { value: "airport", label: "Airport Shuttle" },
  { value: "pariwisata", label: "Bus Pariwisata" },
  { value: "perintis", label: "Bus Perintis" },
  { value: "eksekutif", label: "Bus Eksekutif" },
]
